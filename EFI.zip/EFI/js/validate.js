$(document).ready(function () {
    isValid = $("#regForm").validate({
        rules: {
            pname: {required:true},
            email:{email:true}
        },
        messages:{
            pname:{required:"shop name can not be empty"},
            email: {email:"Provide valid email id"}
        }
    });

    if(isValid){
        console.log(document.querySelector("#regForm").pname.value)
    }
});

